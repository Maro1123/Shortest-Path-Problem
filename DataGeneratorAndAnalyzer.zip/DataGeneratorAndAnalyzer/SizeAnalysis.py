import networkx as nx
import random

for num_nodes in range(50, 3060, 50):
    graph = nx.DiGraph()

    avg_degree = 2

    # Add nodes to the graph
    graph.add_nodes_from(range(num_nodes))

    # Add edges to the graph with random weights
    for node in graph:
        neighbors = list(set(range(num_nodes)) - set(graph.neighbors(node)))
        for i in range(avg_degree):
            if neighbors:
                neighbor = random.choice(neighbors)
                weight = round(random.uniform(0.1, 100.0), 3)
                graph.add_edge(node, neighbor, weight=weight)
                neighbors.remove(neighbor)

    # Print edges and weights in the desired format to a text file
    with open(f"size_analysis_graphs/{num_nodes}_graph.txt", 'w') as f:
        f.write(f"{num_nodes} {graph.number_of_edges()}\n")
        for edge in graph.edges:
            weight = graph.get_edge_data(*edge)['weight']
            f.write(f"{edge[0]} {edge[1]} {weight}\n")
