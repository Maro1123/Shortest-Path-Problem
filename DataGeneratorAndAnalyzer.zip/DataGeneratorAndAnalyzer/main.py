import networkx as nx
import random
import matplotlib.pyplot as plt

graph = nx.DiGraph()

num_nodes = 4000
avg_degree = 8000

# Add nodes to the graph
graph.add_nodes_from(range(num_nodes))

# Add edges to the graph with random weights
for node in graph:
    neighbors = list(set(range(num_nodes)) - set(graph.neighbors(node)))
    for i in range(avg_degree):
        if neighbors:
            neighbor = random.choice(neighbors)
            weight = round(random.uniform(0.1, 100.0), 3)
            graph.add_edge(node, neighbor, weight=weight)
            neighbors.remove(neighbor)

# Print edges and  weights in the desired format to a text file
with open('from_source_node/dense.txt', 'w') as f:
    f.write(f"{num_nodes} {graph.number_of_edges()}\n")
    for edge in graph.edges:
        weight = graph.get_edge_data(*edge)['weight']
        f.write(f"{edge[0]} {edge[1]} {weight}\n")

# Draw the graph
pos = nx.spring_layout(graph)
nx.draw(graph, pos=pos, with_labels=True)
nx.draw_networkx_edge_labels(graph, pos=pos, edge_labels=nx.get_edge_attributes(graph, 'weight'))

plt.show()
