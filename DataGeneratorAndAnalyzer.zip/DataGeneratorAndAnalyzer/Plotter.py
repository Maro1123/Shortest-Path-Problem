import matplotlib.pyplot as plt

# ___________________________________________ Space Analysis _______________________________________________________

with open('plotting_data/X_spaceDensity.txt', 'r') as x_file:
    x_density = [int(line.strip()) for line in x_file]

with open('plotting_data/Y_spaceDijDen.txt', 'r') as y_file:
    y_dijkstra_space_density = [int(line.strip()) for line in y_file]

with open('plotting_data/Y_spaceBellDen.txt', 'r') as y_file:
    y_bellman_space_density = [int(line.strip()) for line in y_file]

with open('plotting_data/Y_spaceFlDen.txt', 'r') as y_file:
    y_floyd_space_density = [int(line.strip()) for line in y_file]

# ___________________________________________ Time Analysis _______________________________________________________

with open('plotting_data/X_spaceSize.txt', 'r') as x_file:
    x_size = [int(line.strip()) for line in x_file]

with open('plotting_data/Y_spaceDijSize.txt', 'r') as y_file:
    y_dijkstra_space_size = [int(line.strip()) for line in y_file]

with open('plotting_data/Y_spaceBellSize.txt', 'r') as y_file:
    y_bellman_space_size = [int(line.strip()) for line in y_file]

with open('plotting_data/Y_spaceFlSize.txt', 'r') as y_file:
    y_floyd_space_size = [int(line.strip()) for line in y_file]

with open('plotting_data/Y_DijkstraSingleSourceSize.txt', 'r') as y_file:
    y_dijkstra_time_size = [int(line.strip()) for line in y_file]

with open('plotting_data/Y_BellmanSingleSourceSize.txt', 'r') as y_file:
    y_bellman_time_size = [int(line.strip()) for line in y_file]

with open('plotting_data/Y_FloydSingleSourceSize.txt', 'r') as y_file:
    y_floyd_time_size = [int(line.strip()) for line in y_file]

with open('plotting_data/Y_DijkstraSizeAllPairs.txt', 'r') as y_file:
    y_dijkstra_time_size_all = [int(line.strip()) for line in y_file]

with open('plotting_data/Y_BellmanSizeAllPairs.txt', 'r') as y_file:
    y_bellman_time_size_all = [int(line.strip()) for line in y_file]

with open('plotting_data/Y_DijkstraDenseSingleSource.txt', 'r') as y_file:
    y_dijkstra_time_single_source_dense = [int(line.strip()) for line in y_file]

with open('plotting_data/Y_BellmanSingleSourceDense.txt', 'r') as y_file:
    y_bellman_time_single_source_dense = [int(line.strip()) for line in y_file]

with open('plotting_data/Y_FloydDense.txt', 'r') as y_file:
    y_floyd_time_dense = [int(line.strip()) for line in y_file]

with open('plotting_data/Y_DijkstraDenseAllPairs.txt', 'r') as y_file:
    y_dijkstra_time_all_pairs_dense = [int(line.strip()) for line in y_file]

with open('plotting_data/Y_BellmanAllPairsDense.txt', 'r') as y_file:
    y_bellman_all_pairs_time_dense = [int(line.strip()) for line in y_file]

# ___________________________________________ Space Analysis _______________________________________________________

plt.figure()
plt.plot(x_density, y_dijkstra_space_density)
plt.plot(x_density, y_bellman_space_density)
plt.plot(x_density, y_floyd_space_density)
plt.title('Space Analysis\nNumber of nodes = 200\n(Dijkstra vs Bellman vs Floyd)')
plt.xlabel('Average Degree')
plt.ylabel('Space')

plt.figure()
plt.plot(x_size, y_dijkstra_space_size)
plt.plot(x_size, y_bellman_space_size)
plt.title('Space analysis\nAverage degree = 2\n(Dijkstra vs Bellman)')
plt.xlabel('Size')
plt.ylabel('Space')

plt.figure()
plt.plot(x_size, y_floyd_space_size)
plt.title('Space analysis\nAverage degree = 2\n(Floyd)')
plt.xlabel('Size')
plt.ylabel('Space')

# ____________________________________ Time Analysis Single Source Size ________________________________________________

plt.figure()
plt.plot(x_size, y_dijkstra_time_size)
plt.plot(x_size, y_bellman_time_size)
plt.title('Time Analysis Average degree = 2\nSingle Source (0)\n (Dijkstra vs Bellman)')
plt.xlabel('Size')
plt.ylabel('Time (nano)')

# ______________________________________ Time Analysis All Pairs Size __________________________________________________

plt.figure()
plt.plot(x_size, y_dijkstra_time_size_all)
plt.plot(x_size, y_bellman_time_size_all)
plt.plot(x_size, y_floyd_time_size)

plt.title('Time Analysis\nAverage degree = 2\nAll Pairs\n(Dijkstra vs Bellman vs Floyd)')
plt.xlabel('Size')
plt.ylabel('Time (micro)')

# ______________________________________ Time Analysis Single Source Dense _____________________________________________

plt.figure()
plt.plot(x_density, y_dijkstra_time_single_source_dense)
plt.plot(x_density, y_bellman_time_single_source_dense)
plt.title('Time Analysis Number of nodes = 200\nSingle Source (0)\n (Dijkstra vs Bellman)')
plt.xlabel('Average degree')
plt.ylabel('Time (micro)')

# _______________________________________ Time Analysis All Pairs Dense _______________________________________________

plt.figure()
plt.plot(x_density, y_dijkstra_time_all_pairs_dense)
plt.plot(x_density, y_bellman_all_pairs_time_dense)
plt.plot(x_density, y_floyd_time_dense)
plt.title('Time Analysis Number of nodes = 200\nAll Pairs\n (Dijkstra vs Bellman vs Floyd)')
plt.xlabel('Average degree')
plt.ylabel('Time (micro)')

plt.figure()
plt.plot(x_density, y_floyd_time_dense)
plt.title('Time Analysis Number of nodes = 200\nAll Pairs\n (Floyd)')
plt.xlabel('Average degree')
plt.ylabel('Time (micro)')

plt.show()
